#!/bin/bash
variable1="sed "
variable1+="command "
variable1+="usage"
echo $variable1
