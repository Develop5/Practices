#!/bin/bash
#Filename: reading.sh
#Description: playing with scripts
ls -la

