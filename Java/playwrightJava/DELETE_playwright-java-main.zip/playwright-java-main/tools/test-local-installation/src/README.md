This directory is populated with test files from playwright and playwright-driver projects. They are copied
here on each test run.
