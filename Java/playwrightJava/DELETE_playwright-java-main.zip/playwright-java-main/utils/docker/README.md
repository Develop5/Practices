# Docker build infra

This folder contains the infra to build the Docker images for Java. It's based on
the upstream code located in [`microsoft/playwright/utils/docker`](https://github.com/microsoft/playwright/tree/main/utils/docker).
