This directory contains sample [`pom.xml`](./pom.xml) and source code for the Playwright examples.

You can run them in terminal like this:

```sh
mvn compile exec:java -Dexec.mainClass=org.example.PageScreenshot
```
