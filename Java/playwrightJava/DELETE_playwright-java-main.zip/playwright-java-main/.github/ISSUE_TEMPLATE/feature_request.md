---
name: Feature request
about: Request new features to be added
title: "[Feature]"
labels: ''
assignees: ''

---

Let us know what functionality you'd like to see in Playwright and what your use case is.
Do you think others might benefit from this as well?
